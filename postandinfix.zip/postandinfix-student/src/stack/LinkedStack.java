package stack;

/**
 * A {@link LinkedStack} is a generic stack that is implemented using
 * a Linked List structure to allow for unbounded size.
 */
public class LinkedStack<T> {

  private LLNode<T> head;
  private int size;

  /**
   * Remove and return the top element on this stack.
   * If stack is empty, return null (instead of throw exception)
   */
  public T pop() {
    if (head == null) {
      return null;
    }
    T info = head.info;
    head = head.link;
    size -= 1;
    return info;
  }

  /**
   * Return the top element of this stack (do not remove the top element).
   * If stack is empty, return null (instead of throw exception)
   */
  public T top() {
    if (head == null) {
      return null;
    }
    T info = head.info;
    return info;
  }

  /**
   * Return true if the stack is empty and false otherwise.
   */
  public boolean isEmpty() {
    if (head == null) {
      return true;
    }
    return false;
  }

  /**
   * Return the number of elements in this stack.
   */
  public int size() {
    // TODO
    return size;
  }

  /**
   * Pushes a new element to the top of this stack.
//   */
  public void push(T elem) {
    LLNode<T> node = new LLNode<T>(elem);
    node.link = head;
    head = node;
    size++;
  }

}
