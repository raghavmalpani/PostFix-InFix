package evaluator;

import parser.ArithParser;
import stack.LinkedStack;

public class InfixEvaluator extends Evaluator {

  private LinkedStack<String> operators = new LinkedStack<String>();
  private LinkedStack<Integer> operands = new LinkedStack<Integer>();

  /** return operands object (for testing purpose). */
  public LinkedStack<String> getOperatorStack() {
    return operators;
  }

  public LinkedStack<Integer> getOperandStack() {
    return operands;
  }

  public void proc(String token) throws Exception {
    if (token.equals("+")) {
      Integer op1 = operands.pop();
      Integer op2 = operands.pop();
      if (op1 == null || op2 == null) {
        throw new Exception("too few operands");
      }
      operands.push(op1 + op2);
    } else if (token.equals("-")) {
      Integer op1 = operands.pop();
      Integer op2 = operands.pop();
      if (op1 == null || op2 == null) {
        throw new Exception("too few operands");
      }
      operands.push(op2 - op1);
    } else if (token.equals("*")) {
      Integer op1 = operands.pop();
      Integer op2 = operands.pop();
      if (op1 == null || op2 == null) {
        throw new Exception("too few operands");
      }
      operands.push(op2 * op1);
    } else if (token.equals("/")) {
      Integer op1 = operands.pop();
      Integer op2 = operands.pop();
      if (op1 == null || op2 == null) {
        throw new Exception("too few operands");
      }
      if (op1 == 0) {
        throw new Exception("division by zero");
      }
      operands.push(op2 / op1);
    } else if (token.equals("!")) {
      Integer op1 = operands.pop();
      if (op1 == null) {
        throw new Exception("too few operands");
      }
      operands.push(0 - op1);
    } else {
      throw new Exception("invalid operator");
    }
  }

  /**
   * This method performs one step of evaluation of a infix expression. The input
   * is a token. Follow the infix evaluation algorithm to implement this method.
   * If the expression is invalid, throw an exception with the corresponding
   * exception message.
   */
  public void evaluate_step(String token) throws Exception {

    if (isOperand(token)) {
      operands.push(Integer.valueOf(token));
    } else {
      if (token.equals("(")) {
        operators.push(token);
      } else if (token.equals(")")) {
        String i = operators.pop();
        while (!(i.equals("("))) {
          proc(i);
          if (operators.top() == null) {
            throw new Exception("missing (");
          }
          i = operators.pop();
        }
      } else {
        if (operators.top() == null || precedence(token) > precedence(operators.top())) {
          //System.out.println("enetered if");
          operators.push(token);
        } else {
          while (operators.top() != null && precedence(token) <= precedence(operators.top())) {
            //System.out.println("entered while");
            proc(operators.pop());
          }
          operators.push(token);
        }
      }


    }
  }

  /**
   * This method evaluates an infix expression (defined by expr) and returns the
   * evaluation result. It throws an Exception object if the infix expression is
   * invalid.
   */
  public Integer evaluate(String expr) throws Exception {

    for (String token : ArithParser.parse(expr)) {
      evaluate_step(token);
    }

    /* TODO: what do we do after all tokens have been processed? */
    while (operators.top() != null) {
      proc(operators.pop());
    }
    // The operand operands should have exactly one operand after the evaluation is
    // done
    if (operands.size() > 1) {
      throw new Exception("too many operands");
    } else if (operands.size() < 1) {
      throw new Exception("too few operands");
    }

    return operands.pop();
  }

  public static void main(String[] args) throws Exception {
    System.out.println(new InfixEvaluator().evaluate("!"));
  }
}
